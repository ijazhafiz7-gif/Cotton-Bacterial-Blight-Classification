# Weka Classifier Results (Cotton, 2700 instances, 10-fold cross-validation)

| Classifier | Accuracy (%) | File |
|---|---|---|
| lazy.IB1 | 93.33 | [Lazy_IB1_93.33.txt](Lazy_IB1_93.33.txt) |
| lazy.IBk | 93.22 | [Lazy_IBk_93.22.txt](Lazy_IBk_93.22.txt) |
| trees.RandomTree | 93.00 | [Trees_RandomTree_93.00.txt](Trees_RandomTree_93.00.txt) |
| meta.RandomCommittee | 92.96 | [Meta_RandomCommittee_92.96.txt](Meta_RandomCommittee_92.96.txt) |
| trees.RandomForest | 92.85 | [Trees_RandomForest_92.85.txt](Trees_RandomForest_92.85.txt) |
| rules.NNge | 92.67 | [Rules_NNge_92.67.txt](Rules_NNge_92.67.txt) |
| meta.RotationForest | 90.89 | [Meta_RotationForest_90.89.txt](Meta_RotationForest_90.89.txt) |
| meta.Decorate | 87.67 | [Meta_Decorate_87.67.txt](Meta_Decorate_87.67.txt) |
| trees.SimpleCart | 86.56 | [Trees_SimpleCart_86.56.txt](Trees_SimpleCart_86.56.txt) |
| trees.J48 | 85.48 | [Trees_J48_85.48.txt](Trees_J48_85.48.txt) |
| trees.J48Graft | 85.48 | [Trees_J48Graft_85.48.txt](Trees_J48Graft_85.48.txt) |
| trees.BFTree | 83.18 | [Trees_BFTree_83.18.txt](Trees_BFTree_83.18.txt) |
